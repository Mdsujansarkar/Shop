/*
( function( $ ) {

	$( window ).on( 'elementor:init', function() {
        elementor.hooks.addAction( 'panel/open_editor/widget/', function( panel, model, view ) {
		elementor.hooks.addAction('panel/open_editor/widget/pp-woo-products', function (panel, model, view) {
			console.log(panel);
		});
        } );
	} );
} )( jQuery );
*/
