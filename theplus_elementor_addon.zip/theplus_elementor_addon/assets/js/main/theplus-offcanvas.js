;(function($) {

	PlusOffcanvas = function( $scope ) {
		
		this.node                 = $scope;
		this.wrap                 = $scope.find('.plus-offcanvas-wrapper');
		this.content              = $scope.find('.plus-canvas-content-wrap');
		this.button               = $scope.find('.offcanvas-toggle-btn');
		this.settings             = this.wrap.data('settings');
		this.id                   = this.settings.content_id;
		this.transition           = this.settings.transition;
		this.esc_close            = this.settings.esc_close;
		this.body_click_close     = this.settings.body_click_close;
		this.direction            = this.settings.direction;
		this.duration             = 500;

		this.destroy();
		this.init();
	};

	PlusOffcanvas.prototype = {
		id: '',
		node: '',
		wrap: '',
		content: '',
		button: '',
		settings: {},
		transition: '',
		duration: 400,
		initialized: false,
		animations: [
			'slide',
			'slide-along',
			'reveal',
			'push',
		],

		init: function () {
			if ( ! this.wrap.length ) {
				return;
			}

			$('html').addClass('plus-offcanvas-content-widget');

			if ( $('.plus-offcanvas-container').length === 0 ) {
				$('body').wrapInner( '<div class="plus-offcanvas-container" />' );
				this.content.insertBefore('.plus-offcanvas-container');
			}

			if ( this.wrap.find('.plus-canvas-content-wrap').length > 0 ) {
                if ( $('.plus-offcanvas-container > .plus-' + this.id).length > 0 ) {
                    $('.plus-offcanvas-container > .plus-' + this.id).remove();
                }
                if ( $('body > .plus-' + this.id ).length > 0 ) {
                    $('body > .plus-' + this.id ).remove();
                }
                $('body').prepend( this.wrap.find('.plus-canvas-content-wrap') );
			}

			this.bindEvents();
		},

		destroy: function() {
			this.close();

			this.animations.forEach(function( animation ) {
				if ( $('html').hasClass( 'plus-' + animation ) ) {
					$('html').removeClass( 'plus-' + animation )
				}
			});

			if ( $('body > .plus-' + this.id ).length > 0 ) {
				//$('body > .plus-' + this.id ).remove();
			}
		},

		bindEvents: function () {
			this.button.on('click', $.proxy( this.toggleContent, this ));

			$('body').delegate( '.plus-canvas-content-wrap .plus-offcanvas-close', 'click', $.proxy( this.close, this ) );

            if ( this.esc_close === 'yes' ) {
                this.closeESC();
            }
            if ( this.body_click_close === 'yes' ) {
                this.closeClick();
            }
		},

		toggleContent: function() {
			if ( ! $('html').hasClass('plus-open') ) {
				this.show();
			} else {
				this.close();
			}
		},

		show: function() {
			$('.plus-' + this.id).addClass('plus-visible');
			// init animation class.
			$('html').addClass( 'plus-' + this.transition );
			$('html').addClass( 'plus-' + this.direction );
			$('html').addClass('plus-open');
			$('html').addClass('plus-' + this.id + '-open');
			$('html').addClass('plus-reset');
            
            this.button.addClass('plus-is-active');
		},

		close: function() {
			$('html').removeClass('plus-open');
			$('html').removeClass('plus-' + this.id + '-open');
			setTimeout($.proxy(function () {
				$('html').removeClass('plus-reset');
				$('html').removeClass( 'plus-' + this.transition );
                $('html').removeClass( 'plus-' + this.direction );
				$('.plus-' + this.id).removeClass('plus-visible');
			}, this), 500);
            
            this.button.removeClass('plus-is-active');
		},

		closeESC: function() {
			var self = this;

			if ( '' === self.settings.esc_close ) {
				return;
			}

			// menu close on ESC key
			$(document).on('keydown', function (e) {
				if (e.keyCode === 27) { // ESC
					self.close();
				}
			});
		},

		closeClick: function() {
			var self = this;

			$(document).on('click', function(e) {
				if ( $(e.target).is('.plus-canvas-content-wrap') || $(e.target).parents('.plus-canvas-content-wrap').length > 0 || $(e.target).is('.offcanvas-toggle-btn') || $(e.target).parents('.offcanvas-toggle-btn').length > 0 ) {
					return;
				} else {
					self.close();
				}
			});
		}
	};

})(jQuery);