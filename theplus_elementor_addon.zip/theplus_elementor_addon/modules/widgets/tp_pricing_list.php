<?php 
/*
Widget Name: Pricing List
Description: Pricing List
Author: Theplus
Author URI: http://posimyththemes.com
*/
namespace TheplusAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;

use TheplusAddons\Theplus_Element_Load;
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class ThePlus_Pricing_List extends Widget_Base {
		
	public function get_name() {
		return 'tp-pricing-list';
	}

    public function get_title() {
        return __('Pricing List', 'theplus');
    }

    public function get_icon() {
        return 'fa fa-file-text theplus_backend_icon';
    }

    public function get_categories() {
        return array('plus-creatives');
    }

    public function get_script_depends() {
        return [
            'theplus_frontend_scripts'
        ];
    }
	public function get_style_depends() {
		return [ 'theplus-pricing-list' ];
	}

    protected function _register_controls() {
	$this->start_controls_section(
			'Pricing_list',
			[
				'label' => __( 'Pricing List', 'theplus' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
	);
	$this->add_control(
			'menu_style',
			[
				'label' => __( 'Style', 'theplus' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style_1',
				'options' => [
					'style_1'  => __( 'Modern', 'theplus' ),
					'style_2' => __( 'Simple', 'theplus' ),
					'style_3' => __( 'Classic', 'theplus' ),
				],
			]
		);
		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'theplus' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Italian Pizza', 'theplus' ),
				'separator' => 'before',
			]
		);
		$this->add_control(
			'title_tag',
			[
				'label' => __( 'Tag', 'theplus' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __( 'Small | Medium | Large', 'theplus' ),
				'placeholder' => __( 'Seprate by "|" ', 'theplus' ),
				'description' => __( 'Display multiple tag use separator e.g. Small | Medium | Large ', 'theplus' ),
				'separator' => 'before',
			]
		);
		$this->add_control(
			'price',
			[
				'label' => __( 'Price', 'theplus' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( '$4.99', 'theplus' ),
				'separator' => 'before',
			]
		);
		$this->add_control(
			'content',
			[
				'label' => __( 'Description', 'theplus' ),
				'type' => Controls_Manager::WYSIWYG,
				'default' => __( 'I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'theplus' ),
				'placeholder' => __( 'Type your description here', 'theplus' ),
				'separator' => 'before',				
			]
		);
		
		
		$this->end_controls_section();
		$this->start_controls_section(
			'Pricing_list_image_option',
			[
				'label' => __( 'Image', 'theplus' ),
				'tab' => Controls_Manager::TAB_CONTENT,
				'condition' => [
					'menu_style' => 'style_3',
				],
			]
		);
		$this->add_control(
			'image_option',
			[
				'label' => __( 'Image', 'theplus' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'menu_style' => 'style_3',
				],
			]
		);
		$this->add_control(
			'img_shape',
			[
				'label' => __( 'Image Shape', 'theplus' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'none',
				'options' => [
					'none'  => __( 'None', 'theplus' ),
					'img-rounded' => __( 'Rounded', 'theplus' ),
					'img-circle' => __( 'Circle', 'theplus' ),
				],
				'condition' => [
					'menu_style' => 'style_3',
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'section_background',
			[
				'label' => __( 'Background Option', 'theplus' ),
				'tab' => Controls_Manager::TAB_CONTENT,
				'condition' => [
					'menu_style' => ['style_1','style_2'],
				],
			]
		);
		$this->start_controls_tabs( 'tabs_content_background' );
		$this->start_controls_tab(
			'tab_content_background_front',
			[
				'label' => __( 'Front', 'theplus' ),
				'condition' => [
					'menu_style' => ['style_1','style_2'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'front_bg_options',				
				'types' => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .pt-plus-food-menu .food-flipbox-front,{{WRAPPER}} .pt-plus-food-menu.food-menu-style-1 .food-menu-box',
				'condition' => [
					'menu_style' => ['style_1','style_2'],
				],
			]
		);
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'tab_content_background_back',
			[
				'label' => __( 'Back', 'theplus' ),
				'condition' => [
					'menu_style' => ['style_2'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'back_bg_options',				
				'types' => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .pt-plus-food-menu .food-flipbox-back',
				'condition' => [
					'menu_style' => ['style_2'],
				],
			]
		);
		$this->end_controls_tab();		
		$this->end_controls_tabs();
	$this->end_controls_section();
	
	/*Start Pricing List Style */
	$this->start_controls_section(
			'Pricing_list_style',
			[
				'label' => __( 'Pricing List Style', 'theplus' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition'    => [
					'menu_style!' => [ 'style_3'],
				],
			]
	);
	$this->add_control(
			'box_align',
			[
				'label' => __( 'Box Align', 'theplus' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'text-left',
				'options' => [
					'text-left' => __( 'Left', 'theplus' ),
					'text-center'  => __( 'Center', 'theplus' ),
					'text-right'  => __( 'Right', 'theplus' ),
				],
				'condition'    => [
					'menu_style' => [ 'style_1' ],
				],
			]
		);
	$this->add_control(
			'box_align_top',
			[
				'label' => __( 'Box Align', 'theplus' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'bottom-left',
				'options' => [
					'top-left' => __( 'Top Left', 'theplus' ),
					'top-right'  => __( 'Top Right', 'theplus' ),					
					'bottom-left'  => __( 'Bottom Left', 'theplus' ),
					'bottom-right'  => __( 'Bottom Right', 'theplus' ),
				],
				'condition'    => [
					'menu_style' => [ 'style_2' ],
				],
			]
		);
	
	$this->end_controls_section();
	/*End Pricing List Style */
	/*Start Pricing List Title */
	$this->start_controls_section(
			'Pricing_list_title_style',
			[
				'label' => __( 'Title Style', 'theplus' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
	);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __( 'Typography', 'theplus' ),
				'selector' => '{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-title',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => __( 'Title Color', 'theplus' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#313131',
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'title_bg_color',
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-title',
				
			]
		);
		
		$this->add_control(
			'title_padding',
			[
				'label' => __( 'Padding', 'theplus' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'title_border',
			[
				'label' => __( 'Border', 'theplus' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'theplus' ),
				'label_off' => __( 'Hide', 'theplus' ),
				'default' => 'no',	
				'condition'    => [					
					'menu_style' => [ 'style_3' ],
				],
			]
		);
		$this->add_control(
			'border_style',
			[
				'label' => __( 'Border', 'theplus' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => theplus_get_border_style(),
				'separator' => 'before',
				'condition' => [
					'title_border' => 'yes',
				],
				'selectors'  => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-title' => 'border-style: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'bd_title_height',
			[
				'label' => __( 'Border Width', 'theplus' ),
				'type'  => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default' => [
					'top'    => 1,
					'right'  => 1,
					'bottom' => 1,
					'left'   => 1,
				],
				'condition' => [
					'title_border' => 'yes',
				],
				'selectors'  => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-title' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],				
			]
		);
		$this->add_responsive_control(
			'title_border_radius',
			[
				'label'      => __( 'Border Radius', 'theplus' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],		
				'condition' => [
					'title_border' => 'yes',
				],
			]
		);
		$this->add_control(
			'bd_title_color',
			[
				'label' => __( 'Border Color', 'theplus' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#f5f5f5',
				'condition' => [
					'title_border' => 'yes',
				],
				'selectors'  => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-title' => 'border-color: {{VALUE}};',
				],				
			]
		);
	$this->end_controls_section();
	/*End Pricing List Title */
	/*Start Pricing List Line */
	$this->start_controls_section(
			'Pricing_list_line_style',
			[
				'label' => __( 'Line Style', 'theplus' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition'    => [					
					'menu_style' => [ 'style_3' ],
				],
			]
	);
	$this->add_control(
			'border_line_style',
			[
				'label' => __( 'Line', 'theplus' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'theplus' ),
				'label_off' => __( 'Hide', 'theplus' ),
				'default' => 'no',	
				
			]
		);
		$this->add_control(
			'line_style',
			[
				'label' => __( 'Line', 'theplus' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => theplus_get_border_style(),
				'separator' => 'before',
				'condition' => [
					'border_line_style' => 'yes',
				],
				'selectors'  => [
					'{{WRAPPER}} .pt-plus-food-menu.food-menu-style-3 .food-flex-line .food-menu-divider .menu-divider' => 'border-style: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'bd_line_height',
			[
				'label' => __( 'Line Width', 'theplus' ),
				'type'  => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default' => [
					'top'    => 1,
					'right'  => 1,
					'bottom' => 1,
					'left'   => 1,
				],
				'condition' => [
					'border_line_style' => 'yes',
				],
				'selectors'  => [
					'{{WRAPPER}} .pt-plus-food-menu.food-menu-style-3 .food-flex-line .food-menu-divider .menu-divider' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],				
			]
		);
		$this->add_control(
			'bd_line_color',
			[
				'label' => __( 'Line Color', 'theplus' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#888',
				'condition' => [
					'border_line_style' => 'yes',
				],
				'selectors'  => [
					'{{WRAPPER}} .pt-plus-food-menu.food-menu-style-3 .food-flex-line .food-menu-divider .menu-divider' => 'border-color: {{VALUE}};',
				],				
			]
		);
	$this->end_controls_section();
	/*End Pricing List Line */
	/*Start Pricing List Tag */
	$this->start_controls_section(
			'Pricing_list_tag_style',
			[
				'label' => __( 'Tag Style', 'theplus' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
	);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tag_typography',
				'label' => __( 'Typography', 'theplus' ),
				'selector' => '{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-tag',
			]
		);
		$this->add_control(
			'tag_right_margin',
			[
				'label' => __( 'Tag Space', 'theplus' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px' ],
				'default' => [
					'unit' => 'px',
					'size' => 5,
				],				
				'range' => [					
					'px' => [
						'min' => 0,
						'max' => 20,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-tag' => 'margin-right: {{SIZE}}{{UNIT}};',
				],				
			]
		);
		$this->add_control(
			'tag_color',
			[
				'label' => __( 'Tag Color', 'theplus' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#313131',
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-tag' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'tag_bg_color',
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-tag',
				
			]
		);
		
		$this->add_responsive_control(
			'tag_border_radius',
			[
				'label'      => __( 'Border Radius', 'theplus' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-tag' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],						
			]
		);
		$this->add_control(
			'tag_padding',
			[
				'label' => __( 'Padding', 'theplus' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-tag' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
	$this->end_controls_section();
	/*End Pricing List Tag */
	/*Start Pricing List Price */
	$this->start_controls_section(
			'Pricing_list_price_style',
			[
				'label' => __( 'Price Style', 'theplus' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
	);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_typography',
				'label' => __( 'Typography', 'theplus' ),
				'selector' => '{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-price',
			]
		);
		$this->add_control(
			'price_color',
			[
				'label' => __( 'Price Color', 'theplus' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#313131',
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-price' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'price_bg_color',
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-price',
				
			]
		);
		
		$this->add_responsive_control(
			'price_border_radius',
			[
				'label'      => __( 'Border Radius', 'theplus' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-price' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],						
			]
		);
		
		$this->add_control(
			'price_padding',
			[
				'label' => __( 'Padding', 'theplus' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
	$this->end_controls_section();
	/*End Pricing List Price */
	/*Start Pricing List desc */
	$this->start_controls_section(
			'Pricing_list_desc_style',
			[
				'label' => __( 'Description Style', 'theplus' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
	);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typography',
				'label' => __( 'Typography', 'theplus' ),
				'selector' => '{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-desc',
			]
		);
		$this->add_control(
			'desc_color',
			[
				'label' => __( 'Description Color', 'theplus' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#313131',
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-desc p' => 'color: {{VALUE}}',
				],
			]
		);		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'desc_bg_color',
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-desc',
				
			]
		);
		
		$this->add_responsive_control(
			'dec_border_radius',
			[
				'label'      => __( 'Border Radius', 'theplus' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-desc' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],						
			]
		);
		
		$this->add_control(
			'dec_padding',
			[
				'label' => __( 'Padding', 'theplus' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
	$this->end_controls_section();
	/*End Pricing List desc */
	/*Start Pricing List Image */
	$this->start_controls_section(
			'Pricing_list_img_style',
			[
				'label' => __( 'Image Style', 'theplus' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
	);
		$this->add_control(
            'img_width',
            [
                'type' => Controls_Manager::SLIDER,
				'label' => __('Image Max Width', 'theplus'),
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
						'step' => 5,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 200,
				],
				'render_type' => 'ui',
				'condition' => [
					'menu_style' => 'style_3',
				],
				'selectors' => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-flex-imgs.food-flex-img' => 'max-width: {{SIZE}}{{UNIT}}',
				],
            ]
		);
		$this->add_control(
			'img_border',
			[
				'label' => __( 'Border', 'theplus' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'theplus' ),
				'label_off' => __( 'Hide', 'theplus' ),
				'default' => 'no',				
			]
		);
		$this->add_control(
			'img_border_style',
			[
				'label' => __( 'Border', 'theplus' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => theplus_get_border_style(),
				'separator' => 'before',
				'condition' => [
					'img_border' => 'yes',
				],
				'selectors'  => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-flex-imgs .food-img img' => 'border-style: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'border_height',
			[
				'label' => __( 'Border Width', 'theplus' ),
				'type'  => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default' => [
					'top'    => 1,
					'right'  => 1,
					'bottom' => 1,
					'left'   => 1,
				],
				'condition' => [
					'img_border' => 'yes',
				],
				'selectors'  => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-flex-imgs .food-img img' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],				
			]
		);
		$this->add_control(
			'border_color',
			[
				'label' => __( 'Border Color', 'theplus' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#f5f5f5',
				'condition' => [
					'img_border' => 'yes',
				],
				'selectors'  => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-flex-imgs .food-img img' => 'border-color: {{VALUE}};',
				],				
			]
		);
		$this->add_responsive_control(
			'border_radius',
			[
				'label'      => __( 'Border Radius', 'theplus' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-flex-imgs .food-img img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],				
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'img_shadow',
				'selector' => '{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-flex-imgs .food-img img',
			]
		);
	$this->end_controls_section();
	/*End Pricing List Image */
	
	/*Adv tab*/
		$this->start_controls_section(
            'section_animation_styling',
            [
                'label' => __('On Scroll View Animation', 'theplus'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'animation_effects',
			[
				'label'   => __( 'In Animation Effect', 'theplus' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'no-animation',
				'options' => theplus_get_animation_options(),
			]
		);
		$this->add_control(
            'animation_delay',
            [
                'type' => Controls_Manager::SLIDER,
				'label' => __('Animation Delay', 'theplus'),
				'default' => [
					'unit' => '',
					'size' => 50,
				],
				'range' => [
					'' => [
						'min'	=> 0,
						'max'	=> 4000,
						'step' => 15,
					],
				],
				'condition' => [
					'animation_effects!' => 'no-animation',
				],
            ]
        );
		$this->add_control(
            'animation_duration_default',
            [
				'label'   => esc_html__( 'Animation Duration', 'theplus' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
				'condition' => [
					'animation_effects!' => 'no-animation',
				],
			]
		);
		$this->add_control(
            'animate_duration',
            [
                'type' => Controls_Manager::SLIDER,
				'label' => __('Duration Speed', 'theplus'),
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'range' => [
					'px' => [
						'min'	=> 100,
						'max'	=> 10000,
						'step' => 100,
					],
				],
				'condition' => [
					'animation_effects!' => 'no-animation',
					'animation_duration_default' => 'yes',
				],
            ]
        );
		$this->add_control(
			'animation_out_effects',
			[
				'label'   => __( 'Out Animation Effect', 'theplus' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'no-animation',
				'options' => theplus_get_out_animation_options(),
				'separator' => 'before',
				'condition' => [
					'animation_effects!' => 'no-animation',
				],
			]
		);
		$this->add_control(
            'animation_out_delay',
            [
                'type' => Controls_Manager::SLIDER,
				'label' => __('Out Animation Delay', 'theplus'),
				'default' => [
					'unit' => '',
					'size' => 50,
				],
				'range' => [
					'' => [
						'min'	=> 0,
						'max'	=> 4000,
						'step' => 15,
					],
				],
				'condition' => [
					'animation_effects!' => 'no-animation',
					'animation_out_effects!' => 'no-animation',
				],
            ]
        );
		$this->add_control(
            'animation_out_duration_default',
            [
				'label'   => esc_html__( 'Out Animation Duration', 'theplus' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
				'condition' => [
					'animation_effects!' => 'no-animation',
					'animation_out_effects!' => 'no-animation',
				],
			]
		);
		$this->add_control(
            'animation_out_duration',
            [
                'type' => Controls_Manager::SLIDER,
				'label' => __('Duration Speed', 'theplus'),
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'range' => [
					'px' => [
						'min'	=> 100,
						'max'	=> 10000,
						'step' => 100,
					],
				],
				'condition' => [
					'animation_effects!' => 'no-animation',
					'animation_out_effects!' => 'no-animation',
					'animation_out_duration_default' => 'yes',
				],
            ]
        );
		$this->end_controls_section();
}	
	protected function render() {
		$settings = $this->get_settings_for_display();		
		$content = $settings['content'];
		$menu_style = $settings['menu_style'];
		$box_align_top = $settings['box_align_top'];
		$box_align = $settings['box_align'];
		$title = $settings['title'];
		$title_tag = $settings['title_tag'];
		$price = $settings['price'];
		
		$img_shape = $settings['img_shape'];
		
		


		$style_class='';
			if($menu_style =="style_1"){
				$style_class = 'style-1';
			}else if($menu_style =="style_2"){
				$style_class = 'style-2';
			}else if($menu_style =="style_3"){
				$style_class = 'style-3';
			}
		$animation_effects=$settings["animation_effects"];
			$animation_delay=$settings["animation_delay"]["size"];			
			if($animation_effects=='no-animation'){
				$animated_class = '';
				$animation_attr = '';
			}else{
				$animate_offset = theplus_scroll_animation();
				$animated_class = 'animate-general';
				$animation_attr = ' data-animate-type="'.esc_attr($animation_effects).'" data-animate-delay="'.esc_attr($animation_delay).'"';
				$animation_attr .= ' data-animate-offset="'.esc_attr($animate_offset).'"';
				if($settings["animation_duration_default"]=='yes'){
					$animate_duration=$settings["animate_duration"]["size"];
					$animation_attr .= ' data-animate-duration="'.esc_attr($animate_duration).'"';
				}
				if(!empty($settings["animation_out_effects"]) && $settings["animation_out_effects"]!='no-animation'){
					$animation_attr .= ' data-animate-out-type="'.esc_attr($settings["animation_out_effects"]).'" data-animate-out-delay="'.esc_attr($settings["animation_out_delay"]["size"]).'"';					
					if($settings["animation_out_duration_default"]=='yes'){						
						$animation_attr .= ' data-animate-out-duration="'.esc_attr($settings["animation_out_duration"]["size"]).'"';
					}
				}
			}
		$description=$food_title=$food_price=$food_img = $food_tag =$food_flex_img='';
		
		if(!empty($settings['image_option']['url'])){
			$img = $settings['image_option']['url'];
			$food_img = '<div class="food-img '.esc_attr($img_shape).'"> <img src="'.$img.'"> </div>';
			$food_flex_img = 'food-flex-img';
		}
			
			if(isset($bg_back_img) && !empty($bg_back_img)){
			$bg_back_img = wp_get_attachment_image_src($bg_back_img, "full");
			$img_bg_back_Src= $bg_back_img[0];			
			}else{$img_bg_back_Src = '';}

			if(isset($bg_img) && !empty($bg_img)){
			$bg_front_img = wp_get_attachment_image_src($bg_img, "full");
			$img_bg_Src = $bg_front_img [0];			
			}else{$img_bg_Src = '';}

			if(!empty($title_tag) ){
				$array=explode("|",$title_tag);
				if(!empty($array[1])){
					foreach($array as $value){
						$food_tag .='<h5 class="food-menu-tag" >'.esc_html($value).'</h5>';
					}
				}else{
					$food_tag ='<h5 class="food-menu-tag" >'.esc_html($title_tag).'</h5>';
				}
			}
			if(!empty($title) ){
				$food_title ='<h3 class="food-menu-title" >'.esc_html($title).'</h3>';
			}
			if(!empty($price) ){
				$food_price ='<h4 class="food-menu-price" >'.esc_html($price).'</h4>';
			}
			
			
			if($content !=''){				
				$description='<div class="food-desc" > '.$content.' </div>';
				}
		
			$uid=uniqid('food_menu');
			
			if ($menu_style == 'style_1'){
				$box_align_1 = $box_align;
			}else{
				$box_align_1 = '';
			}
			
			if ($menu_style== 'style_2'){
				$box_align_top_1 = $box_align_top;
			}else{
				$box_align_top_1 = '';
			}
			
			$food_menu ='<div class="pt-plus-food-menu  '.esc_attr($box_align).' '.esc_attr($uid).'  food-menu-'.esc_attr($style_class).' '.$animated_class.'" data-uid="'.esc_attr($uid).'" '.$animation_attr.'>';
			if ($menu_style == 'style_1'){
				$food_menu.='<div class="food-menu-box">';				
					$food_menu.= $food_tag;
					$food_menu.= $food_title;
					$food_menu.= $description;
					$food_menu.= $food_price;
				$food_menu.='</div>';
			}else if ($menu_style == 'style_2'){
				$food_menu.='<div class="food-menu-box '.esc_attr($box_align_top_1).'">';	
					$food_menu.='<div class="food-flipbox flip-horizontal flip-horizontal height-full">';
						$food_menu.='<div class="food-flipbox-holder height-full perspective bezier-1">';
							$food_menu.='<div class="food-flipbox-front bezier-1 no-backface origin-center">';
								$food_menu.='<div class="food-flipbox-content width-full">';
									$food_menu.= '<div class="food-menu-block">'.$food_tag.'</div>';
									$food_menu.= '<div class="food-menu-block">'.$food_title.'</div>';
									$food_menu.= $food_price;
								$food_menu.='</div>';
							$food_menu.='</div>';
							$food_menu.='<div class="food-flipbox-back fold-back-horizontal no-backface bezier-1 origin-center">';
								$food_menu.='<div class="food-flipbox-content width-full ">';
									$food_menu.='<div class="text-center">';
										$food_menu.= $description;		
									$food_menu.='</div>';
								$food_menu.='</div>';
							$food_menu.='</div>';
						$food_menu.='</div>';
					$food_menu.='</div>';
				$food_menu.='</div>';
			}else if ($menu_style == 'style_3'){
				$food_menu.='<div class="food-menu-box">';
					$food_menu.='<div class="food-menu-flex ">';
						$food_menu.='<div class="food-flex-line ">';
							$food_menu.='<div class="food-flex-imgs '.esc_attr($food_flex_img).'">';
								$food_menu.= $food_img;
							$food_menu.='</div>';		
							$food_menu.='<div class="food-flex-content">';
								$food_menu.= '<div class="food-menu-block">'.$food_tag.'</div>';
								$food_menu.='<div class="food-title-price">';
									$food_menu.= $food_title;
									$food_menu.= '<div class="food-menu-divider"><div class="menu-divider '.esc_attr($settings['border_line_style']).'"></div></div>';
									$food_menu.= $food_price;
								$food_menu.='</div>';
								$food_menu.= $description;
							$food_menu.='</div>';	
						$food_menu.='</div>';	
						
					$food_menu.='</div>';
				$food_menu.='</div>';
			}
			$food_menu.='</div>';
		echo $food_menu;	
	}
	
    protected function content_template() {
		
    }

}

